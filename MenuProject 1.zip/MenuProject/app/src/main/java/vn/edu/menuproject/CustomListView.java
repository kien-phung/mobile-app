package vn.edu.menuproject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomListView extends BaseAdapter {
    private ArrayList<Employee> listEmployee;
    private LayoutInflater layoutInflater;
    private Context context;

    public CustomListView(Context context, ArrayList<Employee> listEmployee) {
        this.listEmployee = listEmployee;
        this.layoutInflater = LayoutInflater.from(context);
        this.context = context;
    }

    @Override
    public int getCount() {
        return this.listEmployee.size();
    }

    @Override
    public Object getItem(int i) {
        return this.listEmployee.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if(view == null){
            view = layoutInflater.inflate(R.layout.custom_listview_emp,null);
            holder = new ViewHolder();
            holder.imageView = (ImageView) view.findViewById(R.id.image_employee);
            holder.idView = (TextView) view.findViewById(R.id.textView_id);
            holder.nameView = (TextView) view.findViewById(R.id.textView_name);
            holder.genderView = (TextView) view.findViewById(R.id.textView_gender);
            holder.addressView = (TextView) view.findViewById(R.id.textView_address);
            holder.phoneView = (TextView) view.findViewById(R.id.textView_phone);
            holder.birthdayView = (TextView) view.findViewById(R.id.txt_birthday);
            holder.departmentView = (TextView) view.findViewById(R.id.txt_department);
            view.setTag(holder);
        }else{
            holder = (ViewHolder) view.getTag();
        }
        Employee empl = this.listEmployee.get(i);
        holder.nameView.setText("Name: " + empl.getName());
        holder.idView.setText("Id: " + empl.getEmpcode());
        holder.genderView.setText("Gender: " + empl.getGender());
        holder.addressView.setText("Address: " + empl.getAddress());
        holder.birthdayView.setText("Birthday: " + empl.getBirthday());
        holder.phoneView.setText("Phone: " + empl.getPhone());
        holder.departmentView.setText("Department: " + empl.getDepcode());
        Bitmap bitmap = BitmapFactory.decodeByteArray(empl.getImage(),0,empl.getImage().length);
        holder.imageView.setImageBitmap(bitmap);
        return view;
    }
    static class ViewHolder{
        ImageView imageView;
        TextView nameView;
        TextView idView;
        TextView genderView;
        TextView addressView;
        TextView phoneView;
        TextView departmentView;
        TextView birthdayView;
    }
    // Convert String into image (Bitmap)
    /*private Bitmap getBitmapFromEncodedString(String encodedString){
        byte[] arr = Base64.decode(encodedString, Base64.URL_SAFE);
        Bitmap image = BitmapFactory.decodeByteArray(arr, 0, arr.length);
        return image;
    }*/
}
