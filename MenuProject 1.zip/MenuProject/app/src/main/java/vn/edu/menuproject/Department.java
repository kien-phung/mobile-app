package vn.edu.menuproject;

public class Department {
    private String code;
    private String name;
    private String phone;

    public Department(String code, String phone, String name) {
        this.code = code;
        this.phone = phone;
        this.name = name;
    }

    public Department() {
        this.code = "";
        this.phone = "";
        this.name = "";
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "Department{" +
                "code='" + code +
                ", name='" + name + "}";
    }
}
