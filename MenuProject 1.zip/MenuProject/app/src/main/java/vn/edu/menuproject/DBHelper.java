package vn.edu.menuproject;

import android.content.ContentValues;
import  android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(@Nullable Context context) {
        super(context, "mydb1", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE Departments("
                +"depcode text primary key, "+
                "depname text, "+
                "phone text);");

        sqLiteDatabase.execSQL("CREATE TABLE Employee(" +
                "empcode TEXT PRIMARY KEY," +     // thêm TEXT vào đây
                "name TEXT," +
                "gender TEXT," +
                "birthday TEXT," +
                "address TEXT," +
                "phone TEXT," +
                "depcode TEXT NOT NULL CONSTRAINT dep_emp REFERENCES Departments(depcode) ON DELETE CASCADE ON UPDATE CASCADE," +
                "image BLOB);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Departments");
        onCreate(sqLiteDatabase);
    }

    public int insertDepartment(Department department) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("depcode", department.getCode());
        values.put("depname", department.getName());
        values.put("phone", department.getPhone());
        int result = (int)db.insert("Departments", null, values);
        db.close();
        return result;
    }

    public ArrayList<Department> getAllDepartments() {
        ArrayList<Department> departments = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.rawQuery("SELECT * FROM Departments", null);

            if (cursor != null && cursor.moveToFirst()) {
                do {
//                    String code = cursor.getString(0);
//                    String name = cursor.getString(1);
//                    String phone = cursor.getString(2);

                    String code = cursor.getString(cursor.getColumnIndexOrThrow("depcode"));
                    String name = cursor.getString(cursor.getColumnIndexOrThrow("depname"));
                    String phone = cursor.getString(cursor.getColumnIndexOrThrow("phone"));

                    // nen su dung cursor.getString(curor.getColumnIndex("depcode")) vi muc dich bao mat

                    departments.add(new Department(code, name, phone));
                } while (cursor.moveToNext());
            }
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return departments;
    }

    public ArrayList<Department> searchDepartment(String code, String name, String phone) {
        ArrayList<Department> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        StringBuilder query = new StringBuilder("SELECT * FROM Departments WHERE 1=1");
        ArrayList<String> args = new ArrayList<>();

        if (!code.isEmpty()) {
            query.append(" AND depcode LIKE ?");
            args.add("%" + code + "%");
        }
        if (!name.isEmpty()) {
            query.append(" AND name LIKE ?");
            args.add("%" + name + "%");
        }
        if (!phone.isEmpty()) {
            query.append(" AND phone LIKE ?");
            args.add("%" + phone + "%");
        }

        Cursor cursor = db.rawQuery(query.toString(), args.toArray(new String[0]));
        if (cursor != null) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                list.add(new Department(cursor.getString(0), cursor.getString(1), cursor.getString(2)));
                cursor.moveToNext();
            }
            cursor.close();
        }
        db.close();
        return list;
    }
    public int updateDepartment(Department dep) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues content = new ContentValues();
        content.put("depname", dep.getName()); // Changed from "name" to "depname" to match table schema
        content.put("phone", dep.getPhone());
        String whereClause = "depcode=?";
        String[] whereArgs = {dep.getCode()};
        int result = db.update("Departments", content, whereClause, whereArgs);
        db.close();
        return result;
    }   

    public int deleteDepartment(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = "depcode=?";
        String whereArgs[] = {id + ""};
        int result = db.delete("Departments", whereClause, whereArgs);
        db.close();
        return result;
    }

    public int insertEmployee(Employee emp){
        SQLiteDatabase db =this.getWritableDatabase();
        ContentValues content = new ContentValues();
        content.put("empcode", emp.getEmpcode());
        content.put("phone", emp.getPhone());
        content.put("name", emp.getName());
        content.put("gender", emp.getGender());
        content.put("birthday", emp.getBirthday());
        content.put("address", emp.getAddress());
        content.put("depcode", emp.getDepcode());
        content.put("image", emp.getImage());
        int result = (int)db.insert("Employee",null, content);
        db.close();
        return result;
    }

    public int updateEmployee(Employee emp){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues content = new ContentValues();
        content.put("name", emp.getName());
        content.put("gender", emp.getGender());
        content.put("birthday", emp.getBirthday());
        content.put("address", emp.getAddress());
        content.put("phone", emp.getPhone());
        content.put("depcode", emp.getDepcode());
        content.put("image", emp.getImage());

        String whereClause = "empcode=?";
        String[] whereArgs = {emp.getEmpcode()};
        int result = db.update("Employee", content, whereClause, whereArgs);
        db.close();
        return result;
    }

    public int deleteEmployee(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = "empcode=?";
        String[] whereArgs = {id};
        int result = db.delete("Employee", whereClause, whereArgs);
        db.close();
        return result;
    }

    public ArrayList<Employee> getAllEmployees(){
        ArrayList<Employee> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Employee", null); // ✅ đúng
        if(cursor != null)
            cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            list.add(new Employee(cursor.getString(0),cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getString(5),
                    cursor.getString(6),
                    cursor.getBlob(7)));
            cursor.moveToNext();
        }
        cursor.close();
        db.close();
        return list;
    }

    public boolean checkEmployeeID(String empID){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Employee WHERE empcode=?", new String[]{empID});
        boolean result = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return result;
    }

    public boolean checkDepartmentID(String depID){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Departments WHERE depcode=?", new String[]{depID});
        boolean result = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return result;
    }
}
