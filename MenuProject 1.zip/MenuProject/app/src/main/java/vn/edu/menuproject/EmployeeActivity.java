package vn.edu.menuproject;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Calendar;

public class EmployeeActivity extends AppCompatActivity {
    private final ArrayList<String> listItem = new ArrayList<>();
    private ArrayList<Department> list_dep = new ArrayList<>();
    private ArrayList<Employee> list_emp = new ArrayList<>();
    private final DBHelper dbHelper = new DBHelper(this);
    private ImageView imgview;
    private EditText edtID, edtName, edtPhone, edtAddress, edtBirthday;
    private Button btn_Save, btn_Exit, btn_Update, btn_Delete, btn_newImage, btn_select;
    private ImageButton btnGetBirthday;
    private Spinner spinner;
    private ListView listView;
    private RadioGroup rg_gender;
    private RadioButton rbt_male, rbt_female;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee);

        setView();
        set_Spinner();
        btnGetBirthday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c = Calendar.getInstance();

                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(EmployeeActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @SuppressLint("SetTextI18n")
                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                edtBirthday.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        },
                        year, month, day);
                datePickerDialog.show();
            }
        });
        btn_Exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btn_newImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, 9999);
            }
        });

        btn_Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fullFields()){
                    Toast.makeText(EmployeeActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    Employee emp = new Employee();
                    emp.setEmpcode(edtID.getText().toString());
                    emp.setName(edtName.getText().toString());
                    emp.setPhone(edtPhone.getText().toString());
                    emp.setAddress(edtAddress.getText().toString());
                    emp.setBirthday(edtBirthday.getText().toString());
                    emp.setImage(ConverttoArrayByte(imgview));
                    String gender = ((RadioButton) findViewById(rg_gender.getCheckedRadioButtonId())).getText().toString();
                    emp.setGender(gender);
                    String[] str = spinner.getSelectedItem().toString().split(" - ");
                    emp.setDepcode(str[0]);
                    if (checkID(emp.getEmpcode())){
                        Toast.makeText(getApplicationContext(),"ID already exists",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (dbHelper.insertEmployee(emp) > 0){
                        Toast.makeText(getApplicationContext(),"Save successfully",Toast.LENGTH_SHORT).show();
                        clearFields();
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Save failed",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        btn_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                list_emp = dbHelper.getAllEmployees();
                listView.setAdapter(new CustomListView(EmployeeActivity.this, list_emp));
                btn_Save.setEnabled(true);
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Employee emp = list_emp.get(i);
                edtID.setText(emp.getEmpcode());
                edtName.setText(emp.getName());
                edtPhone.setText(emp.getPhone());
                edtAddress.setText(emp.getAddress());
                edtBirthday.setText(emp.getBirthday());
                Bitmap bitmap = BitmapFactory.decodeByteArray(emp.getImage(),0,emp.getImage().length);
                imgview.setImageBitmap(bitmap);
//                rg_gender.clearCheck();
//                spinner.setSelection(0);
                if (emp.getGender().equals("Male")){
                    rbt_male.setChecked(true);
                }
                else {
                    rbt_female.setChecked(true);
                }
                for ( int j = 0 ; j < list_dep.size() ; j++){
                    if (list_dep.get(j).getCode().equals(emp.getDepcode())){
                        spinner.setSelection(j);
                    }
                }
                edtID.setEnabled(false);
                btn_Save.setEnabled(false);
            }
        });
        btn_Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(fullFields()){
                    Toast.makeText(EmployeeActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
                else {
                    String id = edtID.getText().toString().trim();
                    String name = edtName.getText().toString().trim();
                    String phone = edtPhone.getText().toString().trim();
                    String address = edtAddress.getText().toString().trim();
                    String birthday = edtBirthday.getText().toString().trim();
                    String gender = ((RadioButton) findViewById(rg_gender.getCheckedRadioButtonId())).getText().toString();
                    String[] str = spinner.getSelectedItem().toString().split(" - ");
                    String depcode = str[0];
                    byte[] image = ConverttoArrayByte(imgview);
                    if (id.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please enter Employee ID to update", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Employee emp = new Employee();
                    emp.setEmpcode(id);
                    emp.setName(name);
                    emp.setPhone(phone);
                    emp.setAddress(address);
                    emp.setBirthday(birthday);
                    emp.setGender(gender);
                    emp.setDepcode(depcode);
                    emp.setImage(image);

                    int rows = dbHelper.updateEmployee(emp);
                    if (rows > 0) {
                        Toast.makeText(getApplicationContext(), "Update successfully!", Toast.LENGTH_SHORT).show();
                        list_emp = dbHelper.getAllEmployees();
                        listView.setAdapter(new CustomListView(EmployeeActivity.this, list_emp));
                        clearFields();
                        btn_Save.setEnabled(true);
                    }
                }
            }
        });

        btn_Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String empCode = edtID.getText().toString();
                if (empCode.isEmpty()){
                    Toast.makeText(getApplicationContext(), "Please enter Employee Code to delete", Toast.LENGTH_LONG).show();
                    return;
                }
                int result = dbHelper.deleteEmployee(empCode);
                if (result > 0){
                    Toast.makeText(getApplicationContext(), "Delete Successfully", Toast.LENGTH_LONG).show();
                    list_emp = dbHelper.getAllEmployees();
                    listView.setAdapter(new CustomListView(EmployeeActivity.this, list_emp));
                    clearFields();
                }
                else {
                    Toast.makeText(getApplicationContext(), "Delete Error!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void setView(){
        imgview = (ImageView) findViewById(R.id.image_employee);
        edtID = (EditText) findViewById(R.id.edittext_id);
        edtName = (EditText) findViewById(R.id.edittext_name);
        edtPhone = (EditText) findViewById(R.id.edittext_phone);
        edtAddress = (EditText) findViewById(R.id.edittextAddress);
        btn_Update = (Button) findViewById(R.id.buttonEmpUpdate);
        btn_Delete = (Button) findViewById(R.id.buttonEmpDelete);
        btn_Exit = (Button) findViewById(R.id.buttonEmpExit);
        btn_Save = (Button) findViewById(R.id.buttonEmpSave);
        spinner = (Spinner) findViewById(R.id.spinner_department);
        listView = (ListView) findViewById(R.id.listviewEmployee);
        edtBirthday = (EditText) findViewById(R.id.edittextBirthday);
        btnGetBirthday = (ImageButton) findViewById(R.id.buttonGetDate);
        btn_newImage = (Button) findViewById(R.id.button_new_image);
        btn_select = (Button) findViewById(R.id.btn_select);
        rg_gender = (RadioGroup) findViewById(R.id.radiogroup_gender);
        rbt_male = (RadioButton) findViewById(R.id.radio_male);
        rbt_female = (RadioButton) findViewById(R.id.radio_female);
    }

    // lay du lieu dua vao spinner
    private void set_Spinner(){
        list_dep = dbHelper.getAllDepartments();
        listItem.add("Choose Department");
        for (Department dep : list_dep) {
            listItem.add(dep.getCode()+" - "+dep.getName());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listItem);
        spinner.setAdapter(adapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 9999 && resultCode == RESULT_OK) {
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            if(bitmap != null){
                imgview.setImageBitmap(bitmap);
            }
            else {
                Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // chuyen anh .png sang dang bit luu vao Model
    private byte[] ConverttoArrayByte(ImageView img){
        BitmapDrawable bitmapDrawable = (BitmapDrawable) img.getDrawable();
        Bitmap bitmap = bitmapDrawable.getBitmap();

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }

    private void clearFields(){
        edtID.setText("");
        edtName.setText("");
        edtPhone.setText("");
        edtAddress.setText("");
        edtBirthday.setText("");
        imgview.setImageResource(R.drawable.man_image);
        rg_gender.clearCheck();
        spinner.setSelection(0);
    }

    private boolean fullFields() {
        String id = edtID.getText().toString().trim();
        String name = edtName.getText().toString().trim();
        String phone = edtPhone.getText().toString().trim();
        String address = edtAddress.getText().toString().trim();
        String birthday = edtBirthday.getText().toString().trim();

        int selectedGenderId = rg_gender.getCheckedRadioButtonId();
        if (selectedGenderId == -1) {
            return true;
        }
        String gender = ((RadioButton) findViewById(selectedGenderId)).getText().toString();

        if (spinner.getSelectedItemPosition() == 0) { // "Choose Department"
            return true;
        }

        byte[] image = ConverttoArrayByte(imgview);

        return id.isEmpty() || name.isEmpty() || phone.isEmpty() ||
                address.isEmpty() || birthday.isEmpty() || gender.isEmpty() || image.length == 0;
    }

    private boolean checkID(String empCode){
        return dbHelper.checkEmployeeID(empCode);
    }
}