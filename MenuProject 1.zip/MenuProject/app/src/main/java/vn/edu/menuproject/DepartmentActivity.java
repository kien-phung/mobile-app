package vn.edu.menuproject;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class DepartmentActivity extends AppCompatActivity {
    private EditText edtID, edtName, edtPhone;
    private ListView listView;
    private Button btnSelect, btnInsert, btnUpdate, btnDelete;
    private DBHelper dbHelper = new DBHelper(this);
    private ImageButton btnExit;
    private ArrayList<Department> list_dep;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department);
        setViews();
        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fullFields()){
                    Toast.makeText(DepartmentActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    Department dep = new Department();
                    dep.setCode(edtID.getText().toString());
                    dep.setName(edtName.getText().toString());
                    dep.setPhone(edtPhone.getText().toString());
//                    if (checkDepartmentID(dep)){
//                        Toast.makeText(DepartmentActivity.this, "Department ID already exists", Toast.LENGTH_SHORT).show();
//                        return;
//                    }
                    if(dbHelper.insertDepartment(dep) > 0){
                        Toast.makeText(DepartmentActivity.this, "Insert success", Toast.LENGTH_SHORT).show();
                        clearFields();
                    } else {
                        Toast.makeText(DepartmentActivity.this, "Insert failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btnSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                set_adapter();
                clearFields();
            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Department selectedDep = list_dep.get(position);
            edtID.setText(selectedDep.getCode());
            edtName.setText(selectedDep.getName());
            edtPhone.setText(selectedDep.getPhone());
            edtID.setEnabled(false);
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fullFields()){
                    Toast.makeText(DepartmentActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
                else {
                    String code = edtID.getText().toString().trim();
                    String name = edtName.getText().toString().trim();
                    String phone = edtPhone.getText().toString().trim();

                    if (code.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please enter department code to update", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Department department = new Department();
                    department.setCode(code);
                    department.setName(name);
                    department.setPhone(phone);

//                    if(checkDepartmentID(department)){
//                        Toast.makeText(DepartmentActivity.this, "Department ID already exists", Toast.LENGTH_SHORT).show();
//                        return;
//                    }
                    int rows = dbHelper.updateDepartment(department);

                    if (rows > 0) {
                        Toast.makeText(getApplicationContext(), "Update successfully!", Toast.LENGTH_SHORT).show();
                        set_adapter();
                        clearFields();
                    } else {
                        Toast.makeText(getApplicationContext(), "Update failed!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String code = edtID.getText().toString().trim();
                String name = edtName.getText().toString().trim();
                String phone = edtPhone.getText().toString().trim();

                if (code.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please enter department code to update", Toast.LENGTH_SHORT).show();
                    return;
                }

                Department department = new Department();
                department.setCode(code);
                department.setName(name);
                department.setPhone(phone);

                int rows = dbHelper.updateDepartment(department);

                if (rows > 0) {
                    Toast.makeText(getApplicationContext(), "Update successfully!", Toast.LENGTH_SHORT).show();
                    set_adapter();
                    clearFields();
                } else {
                    Toast.makeText(getApplicationContext(), "Update failed!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String depCode = edtID.getText().toString();
                if(depCode.isEmpty()){
                    Toast.makeText(getApplicationContext(), "Please enter Department Code to delete", Toast.LENGTH_LONG).show();
                    return;
                }
                int result = dbHelper.deleteDepartment(depCode);
                if (result > 0){
                    Toast.makeText(getApplicationContext(), "Delete Successfully", Toast.LENGTH_LONG).show();
                    set_adapter();
                    clearFields();
                }
                else
                    Toast.makeText(getApplicationContext(), "Delete Error!", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void setViews() {
        edtID = (EditText) findViewById(R.id.edt_id);
        edtName = (EditText) findViewById(R.id.edt_name);
        edtPhone = (EditText) findViewById(R.id.edt_phone);
        listView = (ListView) findViewById(R.id.lv_department);
        btnSelect = (Button) findViewById(R.id.btn_select);
        btnInsert = (Button) findViewById(R.id.btn_insert);
        btnUpdate = (Button) findViewById(R.id.buttonDepUpdate);
        btnDelete = (Button) findViewById(R.id.buttonDepDelete);
        btnExit = (ImageButton) findViewById(R.id.btn_exit);
    }

    private void clearFields() {
        edtID.setText("");
        edtName.setText("");
        edtPhone.setText("");
        edtID.setEnabled(true);
    }

    private void set_adapter() {
        list_dep = dbHelper.getAllDepartments();
        ArrayList<String> list_string = new ArrayList<>();
        for (Department dep : list_dep) {
            list_string.add(dep.toString());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                DepartmentActivity.this, android.R.layout.simple_list_item_1, list_string
        );
        listView.setAdapter(adapter);
    }

    private boolean fullFields(){
        String id = edtID.getText().toString().trim();
        String name = edtName.getText().toString().trim();
        String phone = edtPhone.getText().toString().trim();

        return id.isEmpty() || name.isEmpty() || phone.isEmpty();
    }

//    private boolean checkDepartmentID(Department dep){
//        return dbHelper.checkDepartmentID(dep.getCode());
//    }
}